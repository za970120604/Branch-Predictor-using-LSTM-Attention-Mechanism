import os
import numpy as np
import matplotlib.pyplot as plt
directory_path = "/home/user/CBP-16-Simulation-master/CBP-16-Simulation-master/cbp2016.eval/traces"

from tqdm import tqdm
import numpy as np

PT = 1000000

filenames = os.listdir(directory_path)
image_names = os.listdir("/home/user/CBP-16-Simulation-master/CBP-16-Simulation-master/cbp16sim/pattern_peek/pattern_peek_plot")
# for file_name in file_names:
cnt = 0
for filename in filenames:
    filename= filename[:-13]
    input_file_path = filename + ".txt"
    image_path = filename + ".png"
    if "LONG" in filename:
        continue
    if image_path in image_names:
        cnt += 1
        print("{} has been preinted, printed_counter = {}\n".format(image_path, cnt))
        continue
    container = []
    offset = 0
    with open(input_file_path, 'r') as input_file:
        total_line = input_file.readline() # first line is the number of PC in this tracefile
        for _ in tqdm(range(int(total_line))):
            line = input_file.readline()
            try:
                processed_line = line.strip()
                container.append(int(processed_line))
                if len(container) == PT:
                    plt.title(filename + "_peek_pattern")
                    plt.scatter(range(offset, offset + PT), container, s=1)
                    del container
                    container = []
                    offset += PT
            except:
                pass
        if len(container) != 0:
            plt.title(filename + "_peek_pattern")
            plt.scatter(range(offset, offset + len(container)), container, s=1)
        plt.savefig("./pattern_peek_plot/{}.png".format(filename))
        plt.clf()  # Clear the current figure
        del container
    
